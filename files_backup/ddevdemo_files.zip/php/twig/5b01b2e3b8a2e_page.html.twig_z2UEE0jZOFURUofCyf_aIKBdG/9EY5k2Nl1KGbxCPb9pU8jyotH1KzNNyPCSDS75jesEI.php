<?php

/* themes/contrib/paxton/templates/page.html.twig */
class __TwigTemplate_257562b96c37906e43b79279c590469c61a84383baedddb4ac807f99f10bf849 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 77, "for" => 114);
        $filters = array("raw" => 115, "t" => 272);
        $functions = array();

        try {
            $this->env->getExtension('Twig_Extension_Sandbox')->checkSecurity(
                array('if', 'for'),
                array('raw', 't'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setSourceContext($this->getSourceContext());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 60
        echo "

<!--start: Header and Navbar -->

<nav class=\"navbar navbar-default\" role=\"navigation\">
  <!--start: Container -->
  <div class=\"container\">
    <div class=\"row\">
     <!--- Start : Header -->
    <!-- Sitename and toggle get grouped for better mobile display -->
    <div class=\"navbar-header col-md-3\">
      <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#main-navigation\">
        <span class=\"sr-only\">Toggle navigation</span>
        <span class=\"icon-bar\"></span>
        <span class=\"icon-bar\"></span>
        <span class=\"icon-bar\"></span>
      </button>
      ";
        // line 77
        if ($this->getAttribute(($context["page"] ?? null), "header", array())) {
            // line 78
            echo "        ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "header", array()), "html", null, true));
            echo "
      ";
        }
        // line 80
        echo "    </div>
    <!--- End :Header -->

    <!--- Start: Navigation -->
    <div class=\"col-md-9\">
    ";
        // line 85
        if ($this->getAttribute(($context["page"] ?? null), "primary_menu", array())) {
            // line 86
            echo "      ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "primary_menu", array()), "html", null, true));
            echo "
    ";
        }
        // line 88
        echo "    <!---End: Navigation -->
    </div>
    </div>
  </div>
  <!--/.container-->
</nav>
<!--end: Header and Navbar -->

<!--- Start: Page Title -->
";
        // line 97
        if (($this->getAttribute(($context["page"] ?? null), "page_title", array()) &&  !($context["is_front"] ?? null))) {
            // line 98
            echo "
  <div id=\"page-title\">
    <div id=\"page-title-inner\">
      <!-- start: Container -->
      <div class=\"container\">
        ";
            // line 103
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "page_title", array()), "html", null, true));
            echo "
      </div>
    </div>
  </div>
";
        }
        // line 108
        echo "<!--- End:Page Title -->

<!-- start: Slider -->
";
        // line 111
        if (($context["is_front"] ?? null)) {
            // line 112
            echo "  <div class=\"slider-wrapper\">
    <div id=\"da-slider\" class=\"da-slider\">
      ";
            // line 114
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["slider_content"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["slider_contents"]) {
                // line 115
                echo "        ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar($context["slider_contents"]));
                echo "
      ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['slider_contents'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 117
            echo "      <nav class=\"da-arrows\">
        <span class=\"da-arrows-prev\"></span>
        <span class=\"da-arrows-next\"></span>
      </nav>
    </div>
  </div>
";
        }
        // line 124
        echo "<!-- end: Slider -->

<!--- Start:layout -->
<div id=\"wrapper\">
  <!-- start: Container -->
  <div class=\"container\">
    <!---Start:highlighted -->
      ";
        // line 131
        if ($this->getAttribute(($context["page"] ?? null), "highlighted", array())) {
            // line 132
            echo "        <div class=\"jumbotron\">
          ";
            // line 133
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "highlighted", array()), "html", null, true));
            echo "
        </div>
      ";
        }
        // line 136
        echo "    <!---End:highlighted -->

    <!---Start:content top -->
      ";
        // line 139
        if ($this->getAttribute(($context["page"] ?? null), "content_top", array())) {
            // line 140
            echo "        <div class=\"row\">
          ";
            // line 141
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content_top", array()), "html", null, true));
            echo "
        </div>
      ";
        }
        // line 144
        echo "    <!---End:Content top -->
    <!-- start: Row -->
    <!--start:content -->
    <div class=\"row layout\">
      <!-- Start:Left SideBar -->
      ";
        // line 149
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_first", array())) {
            // line 150
            echo "        <div class=\"sidebar\" >
          <div class = ";
            // line 151
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["sidebarfirst"] ?? null), "html", null, true));
            echo " >
            ";
            // line 152
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "sidebar_first", array()), "html", null, true));
            echo "
          </div>
        </div>
      ";
        }
        // line 156
        echo "      <!-- End:Right SideBar -->

      <!-- Start:content -->
      ";
        // line 159
        if ($this->getAttribute(($context["page"] ?? null), "content", array())) {
            // line 160
            echo "        <div class = \" content_layout \">
          <div class= ";
            // line 161
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["contentlayout"] ?? null), "html", null, true));
            echo ">
            ";
            // line 162
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "breadcrumb", array()), "html", null, true));
            echo "
            ";
            // line 163
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content", array()), "html", null, true));
            echo "
          </div>
        </div>
      ";
        }
        // line 167
        echo "      <!-- End:content -->

      <!-- Start:Right SideBar -->
      ";
        // line 170
        if ($this->getAttribute(($context["page"] ?? null), "sidebar_second", array())) {
            // line 171
            echo "        <div class=\"sidebar\">
          <div class=";
            // line 172
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["sidebarsecond"] ?? null), "html", null, true));
            echo ">
            ";
            // line 173
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "sidebar_second", array()), "html", null, true));
            echo "
          </div>
        </div>
      ";
        }
        // line 177
        echo "      <!-- End:Right SideBar -->
    </div>
    <!---End:Content -->
    <!---Start:content bottom -->
    ";
        // line 181
        if ($this->getAttribute(($context["page"] ?? null), "content_bottom", array())) {
            // line 182
            echo "      <div class=\"row\">
        ";
            // line 183
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "content_bottom", array()), "html", null, true));
            echo "
      </div>
    ";
        }
        // line 186
        echo "    <!-- End:Content Bottom -->
  </div>
</div>
<!--- End:layout -->

<!-- start: Footer Menu -->
";
        // line 192
        if ($this->getAttribute(($context["page"] ?? null), "footer_menu", array())) {
            // line 193
            echo "  <div id=\"footer-menu\" class=\"hidden-sm hidden-xs\">
    <!-- start: Container -->
    <div class=\"container\">
      <!-- start: Row -->
      <div class=\"row\">
        <!-- start: Footer Menu Logo -->
        <div class=\"col-sm-2\">
          <div id=\"footer-menu-logo\">
            <a class=\"brand\" href=";
            // line 201
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["front_page"] ?? null), "html", null, true));
            echo " > ";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["site_name"] ?? null), "html", null, true));
            echo ". </a>
          </div>
        </div>
        <!-- end: Footer Menu Logo -->
        <!-- start: Footer Menu Links-->
        <div class=\"col-sm-9\">
          <div id=\"footer-menu-links\">
            ";
            // line 208
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_menu", array()), "html", null, true));
            echo "
          </div>
        </div>
        <!-- end: Footer Menu Links-->
        <!-- start: Footer Menu Back To Top -->
        <div class=\"col-sm-1\">
          <div id=\"footer-menu-back-to-top\">
            <a href=\"#\"></a>
          </div>
        </div>
        <!-- end: Footer Menu Back To Top -->
      </div>
      <!-- end: Row -->
    </div>
    <!-- end: Container  -->
  </div>
";
        }
        // line 225
        echo "  <!-- end: Footer Menu -->

<!-- start: Footer -->
";
        // line 228
        if ((($this->getAttribute(($context["page"] ?? null), "footer_first", array()) || $this->getAttribute(($context["page"] ?? null), "footer_second", array())) || $this->getAttribute(($context["page"] ?? null), "footer_third", array()))) {
            // line 229
            echo "  <div id=\"footer\">
    <!-- start: Container -->
    <div class=\"container\">
      <!-- start: Row -->
      <div class=\"row\">
        <!--- Start:Footer First Region -->
        <div class = ";
            // line 235
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["footer_class"] ?? null), "html", null, true));
            echo ">
          ";
            // line 236
            if ($this->getAttribute(($context["page"] ?? null), "footer_first", array())) {
                // line 237
                echo "            ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_first", array()), "html", null, true));
                echo "
          ";
            }
            // line 239
            echo "        </div>
        <!--- End :Footer First Region -->
        <!--- Start:Footer Second Region -->
        <div class = ";
            // line 242
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["footer_class"] ?? null), "html", null, true));
            echo ">
          ";
            // line 243
            if ($this->getAttribute(($context["page"] ?? null), "footer_second", array())) {
                // line 244
                echo "            ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_second", array()), "html", null, true));
                echo "
          ";
            }
            // line 246
            echo "        </div>
        <!--- End:Footer Second Region -->
        <!--- Start:Footer third Region -->
        <div class = ";
            // line 249
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["footer_third_class"] ?? null), "html", null, true));
            echo ">
          ";
            // line 250
            if ($this->getAttribute(($context["page"] ?? null), "footer_third", array())) {
                // line 251
                echo "            ";
                echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_third", array()), "html", null, true));
                echo "
          ";
            }
            // line 253
            echo "        </div>
        <!--- End:Footer Third Region -->
      </div>
    </div>
  </div>

";
        }
        // line 260
        echo "
<!---End :Footer -->

<!--- Start:Footer Botoom -->
<div id=\"copyright\">
  <!-- start: Container -->
  <div class=\"container\">
    <div class=\"col-sm-12\">
      ";
        // line 268
        if ($this->getAttribute(($context["page"] ?? null), "footer_bottom", array())) {
            // line 269
            echo "\t";
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, $this->getAttribute(($context["page"] ?? null), "footer_bottom", array()), "html", null, true));
            echo "
      ";
        }
        // line 271
        echo "      <div class=\"clearfix\"></div>
      <div class=\"credited pull-left\"><p class=\"text-center\">";
        // line 272
        echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->renderVar(t("Paxton ported to drupal by")));
        echo " <a href=\"http://dropthemes.in\" target=\"_blank\">DropThemes.in</a></p></div>
      ";
        // line 273
        if (($context["show_social_icons"] ?? null)) {
            // line 274
            echo "\t<div class=\"social pull-right\">
\t  <a href=\"";
            // line 275
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["facebook_url"] ?? null), "html", null, true));
            echo "\"  class=\"bblue\" target=\"_blank\" ><i class=\"fa fa-facebook\"></i></a>
\t  <a href=\"";
            // line 276
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["google_plus_url"] ?? null), "html", null, true));
            echo "\"  class=\"borange\" target=\"_blank\" ><i class=\"fa fa-google-plus\"></i></a>
\t  <a href=\"";
            // line 277
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["twitter_url"] ?? null), "html", null, true));
            echo "\" class=\"blightblue\" target=\"_blank\" ><i class=\"fa fa-twitter\"></i></a>
\t  <a href=\"";
            // line 278
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["linkedin_url"] ?? null), "html", null, true));
            echo "\" class=\"bviolet\" target=\"_blank\"><i class=\"fa fa-linkedin\"></i></a>
\t  <a href=\"";
            // line 279
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["pinterest_url"] ?? null), "html", null, true));
            echo "\" class=\"bred\" target=\"_blank\" ><i class=\"fa fa-pinterest\"></i></a>
\t  <a href=\"";
            // line 280
            echo $this->env->getExtension('Twig_Extension_Sandbox')->ensureToStringAllowed($this->env->getExtension('Drupal\Core\Template\TwigExtension')->escapeFilter($this->env, ($context["rss_url"] ?? null), "html", null, true));
            echo "\" class=\"borange\" target=\"_blank\" ><i class=\"fa fa-rss\"></i></a>
\t</div>
      ";
        }
        // line 283
        echo "    </div>
  </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "themes/contrib/paxton/templates/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  446 => 283,  440 => 280,  436 => 279,  432 => 278,  428 => 277,  424 => 276,  420 => 275,  417 => 274,  415 => 273,  411 => 272,  408 => 271,  402 => 269,  400 => 268,  390 => 260,  381 => 253,  375 => 251,  373 => 250,  369 => 249,  364 => 246,  358 => 244,  356 => 243,  352 => 242,  347 => 239,  341 => 237,  339 => 236,  335 => 235,  327 => 229,  325 => 228,  320 => 225,  300 => 208,  288 => 201,  278 => 193,  276 => 192,  268 => 186,  262 => 183,  259 => 182,  257 => 181,  251 => 177,  244 => 173,  240 => 172,  237 => 171,  235 => 170,  230 => 167,  223 => 163,  219 => 162,  215 => 161,  212 => 160,  210 => 159,  205 => 156,  198 => 152,  194 => 151,  191 => 150,  189 => 149,  182 => 144,  176 => 141,  173 => 140,  171 => 139,  166 => 136,  160 => 133,  157 => 132,  155 => 131,  146 => 124,  137 => 117,  128 => 115,  124 => 114,  120 => 112,  118 => 111,  113 => 108,  105 => 103,  98 => 98,  96 => 97,  85 => 88,  79 => 86,  77 => 85,  70 => 80,  64 => 78,  62 => 77,  43 => 60,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "themes/contrib/paxton/templates/page.html.twig", "/var/www/html/web/themes/contrib/paxton/templates/page.html.twig");
    }
}
